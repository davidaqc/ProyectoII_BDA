import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nabvar-relaciones',
  templateUrl: './nabvar-relaciones.component.html',
  styleUrls: ['./nabvar-relaciones.component.css']
})
export class NabvarRelacionesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
