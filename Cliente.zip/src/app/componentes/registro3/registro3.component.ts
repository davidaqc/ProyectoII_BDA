import { Component, OnInit } from '@angular/core';
import { ServiciosService } from '../../servicios/servicios.service';
import { Voluntario } from '../../interfaces/voluntario.interface';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro3',
  templateUrl: './registro3.component.html',
  styleUrls: ['./registro3.component.css']
})
export class Registro3Component implements OnInit {

  constructor(private router: Router, private api: ServiciosService) { }

  ngOnInit(): void {
  }

  public datosVoluntario = {
    nombre: "",
    edad: "",
    pais: "",
  }


  registrar() {

    if (this.datosVoluntario.nombre != "" && this.datosVoluntario.pais != "" && this.datosVoluntario.edad != "") {
      const voluntario = this.datosVoluntario;

      const voluntarioFinal: Voluntario = {};

      voluntarioFinal.name = voluntario.nombre;
      voluntarioFinal.age = voluntario.edad;
      voluntarioFinal.country = voluntario.pais;
 
      

      this.api.InsertVoluntarios(voluntarioFinal)
        .subscribe(response => {

          alert("Voluntario registrado");
          this.router.navigate(["/registros"]);

        }, (error: any) => {
          alert("Error al intentar conectar con el server");
        });
    } else {
      alert("Los campos nombre, edad y país son obligatorios");
    }

  }

}

