import { Component, OnInit } from '@angular/core';
import { ServiciosService } from '../../servicios/servicios.service';
import { Proyecto } from '../../interfaces/proyecto.interface';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro2',
  templateUrl: './registro2.component.html',
  styleUrls: ['./registro2.component.css']
})
export class Registro2Component implements OnInit {

  constructor(private router: Router, private api: ServiciosService) { }

  ngOnInit(): void {
  }

  public datosProyecto = {
    nombre: "",
    pais: "",
    poblacionMeta: "",
    duracion: "",
  }


  registrar() {

    if (this.datosProyecto.nombre != "" && this.datosProyecto.pais != ""  && this.datosProyecto.poblacionMeta != "" && this.datosProyecto.duracion != "") {
      const proyecto = this.datosProyecto;

      const proyectoFinal: Proyecto = {};

      proyectoFinal.name = proyecto.nombre;
      proyectoFinal.country = proyecto.pais;
      proyectoFinal.targetPopulation = proyecto.poblacionMeta;
      proyectoFinal.durationWeeks = proyecto.duracion;
      

      this.api.InsertProyectos(proyectoFinal)
        .subscribe(response => {

          alert("Proyecto registrado");
          this.router.navigate(["/registros"]);

        }, (error: any) => {
          alert("Error al intentar conectar con el server");
        });
    } else {
      alert("Los campos nombre, pais, población meta y duración son obligatorios");
    }

  }

}
