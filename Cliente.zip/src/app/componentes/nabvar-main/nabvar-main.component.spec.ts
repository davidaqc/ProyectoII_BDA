import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NabvarMainComponent } from './nabvar-main.component';

describe('NabvarMainComponent', () => {
  let component: NabvarMainComponent;
  let fixture: ComponentFixture<NabvarMainComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NabvarMainComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NabvarMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
