import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nabvar-main',
  templateUrl: './nabvar-main.component.html',
  styleUrls: ['./nabvar-main.component.css']
})
export class NabvarMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
