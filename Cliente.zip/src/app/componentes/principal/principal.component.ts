import { Component, OnInit } from '@angular/core';
import { ServiciosService } from '../../servicios/servicios.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {

  constructor(private router: Router, private api: ServiciosService) { }

  ngOnInit(): void {
  }


  registrar() {
    this.router.navigate(["/registros"]);

  }

  relacionar(){
    this.router.navigate(["/relaciones"])
  }

  consultar(){
    this.router.navigate(["/consultas"])
  }

}
