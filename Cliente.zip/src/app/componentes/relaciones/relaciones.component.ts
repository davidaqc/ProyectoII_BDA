import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-relaciones',
  templateUrl: './relaciones.component.html',
  styleUrls: ['./relaciones.component.css']
})
export class RelacionesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
