import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nabvar-registros',
  templateUrl: './nabvar-registros.component.html',
  styleUrls: ['./nabvar-registros.component.css']
})
export class NabvarRegistrosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
