import { Component, OnInit } from '@angular/core';
import { ServiciosService } from '../../servicios/servicios.service';
import { Organizacion } from '../../interfaces/organizacion.interface';
import { Router } from '@angular/router';
@Component({
  selector: 'app-registro1',
  templateUrl: './registro1.component.html',
  styleUrls: ['./registro1.component.css']
})
export class Registro1Component implements OnInit {

  constructor(private router: Router, private api: ServiciosService) { }

  ngOnInit(): void {
  }

  public datosOrganizacion = {
    nombre: "",
    pais: "",
  }


  registrar() {

    if (this.datosOrganizacion.nombre != "" && this.datosOrganizacion.pais != "") {
      const organizacion = this.datosOrganizacion;

      const organizacionFinal: Organizacion = {};

      organizacionFinal.name = organizacion.nombre;
      organizacionFinal.country = organizacion.pais;
      
      
      this.api.InsertOrganizaciones(organizacionFinal)
        .subscribe(response => {

          alert("Organizacion registrada");
          this.router.navigate(["/registros"]);

        }, (error: any) => {
          alert("Error al intentar conectar con el server");
        });
    } else {
      alert("Los campos nombre y pais son obligatorios");
    }

  }

}
