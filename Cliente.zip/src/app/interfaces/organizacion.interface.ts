export interface Organizacion {
	name?: string,	
	country?: string
}