export interface Voluntario {
	name?: string,
    age?: string,	
	country?: string
}