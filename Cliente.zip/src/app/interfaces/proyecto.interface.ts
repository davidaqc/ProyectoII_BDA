export interface Proyecto {
	name?: string,	
	country?: string,
	targetPopulation?: string,
	durationWeeks?: string,
	vQuantity?: string,
	vName?: string
}